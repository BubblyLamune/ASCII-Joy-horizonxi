--[[
 *	Zone	:: Ilrusi_Atoll
 *  ZoneID	:: 55
 *  Total	:: 20
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17002510", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[2] = { nm="N", id="17002511", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[3] = { nm="N", id="17002512", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[4] = { nm="N", id="17002509", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[5] = { nm="N", id="17002514", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[6] = { nm="N", id="17002515", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[7] = { nm="N", id="17002516", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[8] = { nm="N", id="17002513", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[9] = { nm="N", id="17002508", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[10] = { nm="N", id="17002498", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[11] = { nm="N", id="17002506", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[12] = { nm="N", id="17002497", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[13] = { nm="N", id="17002499", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[14] = { nm="N", id="17002500", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[15] = { nm="N", id="17002501", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[16] = { nm="N", id="17002507", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[17] = { nm="N", id="17002503", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[18] = { nm="N", id="17002504", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[19] = { nm="N", id="17002505", name="Cursed_Chest", mj="1", sj="1", mlvl="65-70", behavior="0", aggro="T(H),M", links="N", spawntype="128", weak="Dark", note="" }
	mb_data[20] = { nm="N", id="17002502", name="Percipient_Fish", mj="7", sj="7", mlvl="65-70", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="Ice,Lightning", note="" }

	return mb_data;
