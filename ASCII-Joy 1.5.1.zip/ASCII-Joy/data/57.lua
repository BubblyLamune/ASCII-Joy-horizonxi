--[[
 *	Zone	:: Talacca_Cove
 *  ZoneID	:: 57
 *  Total	:: 7
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17010728", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[2] = { nm="N", id="17010731", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[3] = { nm="N", id="17010730", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[4] = { nm="N", id="17010729", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[5] = { nm="N", id="17010727", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[6] = { nm="N", id="17010726", name="Gessho", mj="13", sj="13", mlvl="70-70", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }
	mb_data[7] = { nm="N", id="17010725", name="Gessho", mj="13", sj="13", mlvl="80-80", behavior="0", aggro="NA", links="N", spawntype="128", weak="Ice", note="" }

	return mb_data;
