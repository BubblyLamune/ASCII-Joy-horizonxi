--[[
 *	Zone	:: Navukgo_Execution_Chamber
 *  ZoneID	:: 64
 *  Total	:: 1
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17039400", name="Khimaira13", mj="1", sj="1", mlvl="75-75", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="Ice,Earth", note="" }

	return mb_data;
