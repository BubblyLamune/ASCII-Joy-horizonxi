--[[
 *	Zone	:: Periqia
 *  ZoneID	:: 56
 *  Total	:: 10
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17006755", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[2] = { nm="N", id="17006762", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[3] = { nm="N", id="17006761", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[4] = { nm="N", id="17006760", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[5] = { nm="N", id="17006759", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[6] = { nm="N", id="17006758", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[7] = { nm="N", id="17006757", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[8] = { nm="N", id="17006756", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[9] = { nm="N", id="17006754", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }
	mb_data[10] = { nm="N", id="17006763", name="K23H1-LAMIA", mj="11", sj="11", mlvl="78-78", behavior="0", aggro="T(S)", links="Y", spawntype="128", weak="Ice,Lightning", note="" }

	return mb_data;
