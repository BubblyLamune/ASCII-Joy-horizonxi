--[[
 *	Zone	:: Zeruhn_Mines
 *  ZoneID	:: 172
 *  Total	:: 61
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17481783", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[2] = { nm="N", id="17481784", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[3] = { nm="N", id="17481785", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[4] = { nm="N", id="17481788", name="Veindigger_Leech", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Light", note="" }
	mb_data[5] = { nm="N", id="17481743", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[6] = { nm="N", id="17481740", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[7] = { nm="N", id="17481762", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[8] = { nm="N", id="17481741", name="River_Crab", mj="7", sj="7", mlvl="2-4", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[9] = { nm="N", id="17481764", name="Soot_Crab", mj="7", sj="7", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[10] = { nm="N", id="17481782", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[11] = { nm="N", id="17481774", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[12] = { nm="N", id="17481775", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[13] = { nm="N", id="17481742", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[14] = { nm="N", id="17481781", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[15] = { nm="N", id="17481763", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[16] = { nm="N", id="17481779", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[17] = { nm="N", id="17481778", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[18] = { nm="N", id="17481777", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[19] = { nm="N", id="17481776", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[20] = { nm="N", id="17481768", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[21] = { nm="N", id="17481767", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[22] = { nm="N", id="17481766", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[23] = { nm="N", id="17481746", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[24] = { nm="N", id="17481745", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[25] = { nm="N", id="17481744", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[26] = { nm="N", id="17481765", name="Soot_Crab", mj="7", sj="7", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[27] = { nm="N", id="17481789", name="Veindigger_Leech", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Light", note="" }
	mb_data[28] = { nm="N", id="17481786", name="Veindigger_Leech", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Light", note="" }
	mb_data[29] = { nm="N", id="17481787", name="Veindigger_Leech", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Light", note="" }
	mb_data[30] = { nm="N", id="17481780", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[31] = { nm="N", id="17481729", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[32] = { nm="N", id="17481758", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[33] = { nm="N", id="17481760", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[34] = { nm="N", id="17481756", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[35] = { nm="N", id="17481761", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[36] = { nm="N", id="17481731", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[37] = { nm="N", id="17481730", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[38] = { nm="N", id="17481771", name="Soot_Crab", mj="7", sj="7", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[39] = { nm="N", id="17481770", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[40] = { nm="N", id="17481769", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[41] = { nm="N", id="17481755", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[42] = { nm="N", id="17481754", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[43] = { nm="N", id="17481753", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[44] = { nm="N", id="17481752", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[45] = { nm="N", id="17481751", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[46] = { nm="N", id="17481750", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[47] = { nm="N", id="17481749", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[48] = { nm="N", id="17481748", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[49] = { nm="N", id="17481733", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[50] = { nm="N", id="17481734", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[51] = { nm="N", id="17481732", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[52] = { nm="N", id="17481747", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[53] = { nm="N", id="17481738", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[54] = { nm="N", id="17481757", name="Burrower_Worm", mj="4", sj="5", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Wind,Light", note="" }
	mb_data[55] = { nm="N", id="17481737", name="River_Crab", mj="7", sj="7", mlvl="2-4", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[56] = { nm="N", id="17481736", name="Ding_Bats", mj="1", sj="1", mlvl="1-3", behavior="0", aggro="NA", links="N", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }
	mb_data[57] = { nm="N", id="17481735", name="River_Crab", mj="7", sj="7", mlvl="2-4", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[58] = { nm="N", id="17481773", name="Soot_Crab", mj="7", sj="7", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[59] = { nm="N", id="17481739", name="River_Crab", mj="7", sj="7", mlvl="2-4", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[60] = { nm="N", id="17481772", name="Soot_Crab", mj="7", sj="7", mlvl="81-84", behavior="0", aggro="NA", links="N", spawntype="0", weak="Ice,Lightning", note="" }
	mb_data[61] = { nm="N", id="17481759", name="Colliery_Bat", mj="1", sj="1", mlvl="81-84", behavior="0", aggro="NA", links="Y", spawntype="0", weak="Piercing,Ice,Wind,Lightning,Light", note="" }

	return mb_data;
